yajsw-beta-12.07

    	* bug: Cannot specify colon in wrapper.console.title
	* bug: error in AlphaNumericComparator when sorting parameters and classpath
	* bug: posix: env vars are not inherited by subprocess if created with posix_spawn
	* bug: configuration include does not work
	* bug: configuration does not correctly read lists
	* change: support working dir with non latin chars
	* change: windows: change drive or UNC path when executing batch files